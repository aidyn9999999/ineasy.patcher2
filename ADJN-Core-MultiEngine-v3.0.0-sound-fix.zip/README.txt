ADJN Method v2.0 — Extension for Microsoft Edge & Google Chrome
By Adekjamannow / Develop by F R Y 60fps

CARA PASANG DI MICROSOFT EDGE:
1. Buka Microsoft Edge.
2. Di address bar, ketik: edge://extensions lalu tekan Enter.
3. Di panel sebelah kiri bawah, aktifkan toggle "Developer mode" (Mode Pengembang).
4. Klik tombol "Load unpacked" (Muat yang belum dibongkar) di bagian atas.
5. Pilih folder ini:
   d:\coding\method\ADJN-Method-Extension
6. Selesai! Ekstensi ADJN Method v2.0 aktif.

CARA KERJA KETIKA DIKASIH SOUND DI TIKTOK STUDIO:
- Ketika kamu mengunggah video di studio.tiktok.com dan memilih Sound / Musik, ekstensi ini otomatis mencegat request publish dan menonaktifkan "Cloud Canvas Video Editor".
- Hasilnya: Video 4K/120fps atau video patcher kamu TIDAK AKAN di-recompress oleh server TikTok, bitstream video tetap utuh 100%, dan suara musik tetap terpasang dengan aman!


PASSWORD ACCESS UPDATE
Before Auto-Patch is active, TikTok Studio shows an ADJN password gate. User names and size limits are configured in content.js under ACCESS_USERS.


PUBLIC VERSION UPDATE
Popup ekstensi sekarang memiliki toggle Public Version. Jika aktif, password tidak diperlukan dan batas video menjadi 50 MB. Jika dimatikan, sistem kembali ke password/access key sesuai ACCESS_USERS di content.js.
